import arcpy
import pythonaddins

class Tool1(object):
    """Implementation for Extent_addin.tool1 (Tool)"""
    def __init__(self):
        self.enabled = True
        self.shape = "Rectangle" # Can set to "Line", "Circle" or "Rectangle" for interactive shape drawing and to activate the onLine/Polygon/Circle event sinks.
    
    def onRectangle(self, rectangle_geometry):
        #create random points within extent of rectanble
        if arcpy.Exists(r'in_memory\ran_points'):
            arcpy.Delete_management(r'in_memory\ran_points')
        arcpy.CreateRandomPoints_management('in_memory','ran_points','', rectangle_geometry,60)
        
        arcpy.RefreshActiveView()
        arcpy.RefreshTOC()
        pythonaddins.MessageBox('30 Random points created as layer in memory','On rectangle event',0)
