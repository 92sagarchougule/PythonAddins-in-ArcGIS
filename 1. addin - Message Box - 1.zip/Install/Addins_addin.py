import arcpy
import pythonaddins

class ButtonClass1(object):
    """Implementation for Addins_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        message = pythonaddins.MessageBox('This is Message regarding addin tool preparation in python','Tool for spatial data base',1)
        if message == 'OK':
            print('Have you select OK')
        else:
            print('You have select else than ok')
